package com.excel.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.excel.demo.excel.UserExcelImporter;
import com.excel.demo.model.Student;
import com.excel.demo.repository.StudentRepository;

@RestController
//@RequestMapping("/get")
public class StudentController {
	
	@Autowired
	StudentRepository repository;
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String save(@RequestParam("file") MultipartFile file) {
		repository.saveAll(new UserExcelImporter(file).excelImport());
		return "Data Saved";
	}
	
	@RequestMapping("/get")
	//@GetMapping("/")
	public List<Student> getData(){
		 //List<Student> list = repository.findAll();
		 return repository.findAll();
		
	}
}
